"use client";

import { useMemo } from "react";
import DatePicker from "react-multi-date-picker";
import DateObject from "react-date-object";
import persian from "react-date-object/calendars/persian";
import persianFa from "react-date-object/locales/persian_fa";

import styles from "./InlinePersianDatePicker.module.css";

type InlinePersianDatePickerProps = {
  value?: string | null;
  disabled?: boolean;
  ariaLabel?: string;
  placeholder?: string;
  allowPastDates?: boolean;
  onChange: (date: string) => void;
};

function CalendarIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="17"
      height="17"
      aria-hidden="true"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M7 3v3M17 3v3M4.5 9h15" />
      <rect x="4" y="5" width="16" height="15" rx="3" />
      <path d="M8 13h.01M12 13h.01M16 13h.01M8 16.5h.01M12 16.5h.01" />
    </svg>
  );
}

function toEnglishDigits(value: string | number | null | undefined) {
  return String(value ?? "")
    .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));
}

function createDateValue(value?: string | null) {
  const normalized = toEnglishDigits(value).trim();
  if (!/^\d{4}\/\d{2}\/\d{2}$/.test(normalized)) return null;

  try {
    return new DateObject({
      date: normalized,
      format: "YYYY/MM/DD",
      calendar: persian,
      locale: persianFa,
    });
  } catch {
    return null;
  }
}

export default function InlinePersianDatePicker({
  value,
  disabled = false,
  ariaLabel = "تاریخ",
  placeholder = "انتخاب تاریخ",
  allowPastDates = true,
  onChange,
}: InlinePersianDatePickerProps) {
  const selectedDate = useMemo(() => createDateValue(value), [value]);
  const today = useMemo(
    () => new DateObject({ calendar: persian, locale: persianFa }),
    [],
  );

  return (
    <div className={styles.wrapper} aria-label={ariaLabel}>
      <DatePicker
        value={selectedDate}
        calendar={persian}
        locale={persianFa}
        format="YYYY/MM/DD"
        onChange={(date) => {
          if (!date || Array.isArray(date)) return;
          const normalized = toEnglishDigits(date.format("YYYY/MM/DD")).trim();
          if (/^\d{4}\/\d{2}\/\d{2}$/.test(normalized)) onChange(normalized);
        }}
        minDate={allowPastDates ? undefined : today}
        editable={false}
        disabled={disabled}
        placeholder={placeholder}
        calendarPosition="bottom-right"
        portal
        zIndex={2147483647}
        fixMainPosition
        fixRelativePosition
        containerClassName={styles.container}
        inputClass={styles.input}
        className={styles.calendar}
      />
      <span className={styles.icon}>
        <CalendarIcon />
      </span>
    </div>
  );
}
