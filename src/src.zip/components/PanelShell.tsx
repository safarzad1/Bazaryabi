"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import AppIcon from "./AppIcon";

type Role = "admin" | "marketer" | "customer";
const menus = {
  admin: [
    ["/admin/dashboard","داشبورد","dashboard"], ["#","سفارش‌ها","orders"], ["#","محصولات و برندها","products"], ["#","مشتریان","users"], ["#","بازاریاب‌ها","marketer"], ["/admin/reports","گزارشات","reports"],
  ],
  marketer: [
    ["/marketer/dashboard","داشبورد من","dashboard"], ["#","مشتریان من","users"], ["#","ثبت سفارش","orders"], ["#","محصولات","products"], ["/marketer/reports","گزارش عملکرد","reports"],
  ],
  customer: [
    ["/customer/home","خانه","home"], ["#","محصولات","products"], ["#","سبد خرید","cart"], ["/customer/orders","سفارش‌های من","orders"], ["#","حساب کاربری","profile"],
  ],
} as const;

export default function PanelShell({ role, title, subtitle, children }: { role: Role; title: string; subtitle: string; children: React.ReactNode }) {
  const path = usePathname();
  const names = { admin: "مدیر سامانه", marketer: "علی رضایی", customer: "فروشگاه نمونه" };
  return <div className={`app-shell role-${role}`}>
    <aside className="sidebar">
      <div className="sidebar-brand"><div className="mini-logo">ب</div><div><strong>بازاریابی</strong><span>فروش و سفارش‌گیری</span></div></div>
      <nav>{menus[role].map(([href,label,icon])=><Link key={label} href={href} className={path===href ? "active" : href==="#" ? "disabled-link" : ""}><AppIcon name={icon} size={20}/><span>{label}</span></Link>)}</nav>
      <div className="sidebar-bottom"><Link href="/login"><AppIcon name="logout" size={20}/><span>خروج از سامانه</span></Link></div>
    </aside>
    <div className="app-main">
      <header className="topbar"><div className="mobile-brand"><div className="mini-logo">ب</div><strong>بازاریابی</strong></div><div className="topbar-user"><div className="avatar">{names[role].slice(0,1)}</div><div><strong>{names[role]}</strong><span>{role==="admin" ? "مدیریت کل" : role==="marketer" ? "بازاریاب فروش" : "مشتری"}</span></div></div><div className="topbar-actions"><button className="icon-button"><AppIcon name="search" size={19}/></button><div className="date-pill">پنجشنبه ۲ مهر ۱۴۰۵</div></div></header>
      <main className="content"><section className="page-hero"><div><span className="hero-chip">سامانه بازاریابی • {role==="admin" ? "مدیریت" : role==="marketer" ? "پنل بازاریاب" : "خرید و سفارش"}</span><h1>{title}</h1><p>{subtitle}</p></div><div className="hero-art"><span/><span/><span/></div></section>{children}</main>
    </div>
  </div>;
}
