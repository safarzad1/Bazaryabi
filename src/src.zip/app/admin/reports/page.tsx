import PanelShell from "@/components/PanelShell";
import { reportRows } from "@/lib/demo-data";
import { OrdersBarChart, SalesChart } from "@/components/DashboardWidgets";
import AppIcon from "@/components/AppIcon";

export default function AdminReports() {
  return <PanelShell role="admin" title="گزارشات و تحلیل فروش" subtitle="گزارش‌های نموداری و جزئی با امکان فیلتر، مقایسه و Drill-down.">
    <section className="filter-panel"><div className="filter-title"><AppIcon name="reports" size={20}/><b>فیلتر گزارش</b></div><label>از تاریخ<input defaultValue="۱۴۰۵/۰۷/۰۱"/></label><label>تا تاریخ<input defaultValue="۱۴۰۵/۰۷/۳۰"/></label><label>بازاریاب<select defaultValue=""><option value="">همه بازاریاب‌ها</option><option>علی رضایی</option><option>مریم کریمی</option></select></label><label>منطقه<select defaultValue=""><option value="">همه مناطق</option><option>منطقه ۱</option><option>منطقه ۲</option></select></label><button className="primary-button small">اعمال فیلتر</button></section>
    <section className="dashboard-grid wide-left"><SalesChart/><OrdersBarChart/></section>
    <section className="report-catalog"><div className="section-title"><div><span className="eyebrow">فهرست گزارش‌ها</span><h2>گزارش‌های تفصیلی</h2></div><span className="muted-badge">۶ گزارش اصلی</span></div><div className="report-grid">{reportRows.map((r,i)=><article className={`report-item accent-${(i%3)+1}`} key={r.title}><div className="report-number">{i+1}</div><div><span className="report-group">{r.group}</span><h3>{r.title}</h3><p>{r.desc}</p><footer><span>{r.count}</span><button>مشاهده جزئیات ←</button></footer></div></article>)}</div></section>
  </PanelShell>;
}
