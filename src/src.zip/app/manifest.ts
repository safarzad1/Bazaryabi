import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "سامانه بازاریابی و سفارش‌گیری",
    short_name: "بازاریابی",
    description: "PWA بازاریابی، سفارش‌گیری و فروش",
    start_url: "/login",
    display: "standalone",
    background_color: "#eef5fb",
    theme_color: "#173f68",
    lang: "fa",
    dir: "rtl",
    icons: [
      { src: "/icon-192.svg", sizes: "192x192", type: "image/svg+xml" },
      { src: "/icon-512.svg", sizes: "512x512", type: "image/svg+xml" },
    ],
  };
}
