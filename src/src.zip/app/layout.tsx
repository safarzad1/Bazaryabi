import type { Metadata } from "next";
import "../Styles/globals.css";
import PWARegister from "@/components/PWARegister";

export const metadata: Metadata = {
  title: "سامانه بازاریابی و سفارش‌گیری",
  description: "PWA بازاریابی، سفارش‌گیری و فروش",
  applicationName: "سامانه بازاریابی",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "بازاریابی" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl">
      <body>
        <PWARegister />
        {children}
      </body>
    </html>
  );
}
